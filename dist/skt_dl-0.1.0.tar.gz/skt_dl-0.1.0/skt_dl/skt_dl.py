"""
Main module for running skt-dl directly
This is a wrapper around the cli module
"""

from .cli import main

if __name__ == "__main__":
    main()